﻿var randomColor = "#" + ((1 << 24) * Math.random() | 0).toString(16);

document.documentElement.style.setProperty('main-bg-color', randomColor);